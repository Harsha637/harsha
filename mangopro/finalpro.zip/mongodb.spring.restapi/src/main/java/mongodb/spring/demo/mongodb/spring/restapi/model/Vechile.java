package mongodb.spring.demo.mongodb.spring.restapi.model;

import org.springframework.data.annotation.Id;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Vechile {
	
	@Id
	int vid;
	String model;
    String type;
    String branding;
	int numberveh;
	String cost;
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBranding() {
		return branding;
	}
	public void setBranding(String branding) {
		this.branding = branding;
	}
	public int getNumberveh() {
		return numberveh;
	}
	public void setNumberveh(int numberveh) {
		this.numberveh = numberveh;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Vechile [vid=" + vid + ", model=" + model + ", type=" + type + ", branding=" + branding + ", numberveh="
				+ numberveh + ", cost=" + cost + "]";
	}
	public Vechile(int vid, String model, String type, String branding, int numberveh, String cost) {
		super();
		this.vid = vid;
		this.model = model;
		this.type = type;
		this.branding = branding;
		this.numberveh = numberveh;
		this.cost = cost;
	}
	public Vechile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
