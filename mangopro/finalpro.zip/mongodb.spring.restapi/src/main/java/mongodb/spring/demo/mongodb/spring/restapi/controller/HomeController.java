package mongodb.spring.demo.mongodb.spring.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import mongodb.spring.demo.mongodb.spring.restapi.dao.UserDao;
import mongodb.spring.demo.mongodb.spring.restapi.model.ShowVechiles;
import mongodb.spring.demo.mongodb.spring.restapi.model.User;
import mongodb.spring.demo.mongodb.spring.restapi.model.Vechile;
import mongodb.spring.demo.mongodb.spring.restapi.model.show.ShowUser;


@CrossOrigin
@RestController

public class HomeController {
	
	
	@Autowired
	UserDao dao;
	

	@PostMapping("saveuser")
	public User saveUserinfo(@RequestBody User user)
	{

	return dao.CreateUser(user);

	}
	
	
	
	
	
	
	@PostMapping("savevech")
	public ShowVechiles savevechinfo(@RequestBody ShowVechiles showvechiles)
	{

	return dao.Createvech(showvechiles);

	}
	@PutMapping(value="login/{user_Name}/{user_password}")
	public Object getLoginvalidate(Model model,@PathVariable("user_Name") String user_Name,@PathVariable("user_password") String user_password) {
	User User=dao.getDetailsByName(user_Name);
	System.out.println(User);
	String password=User.getUser_password();
	System.out.println(password);
	
	 if(password.equals(user_password))
	 {
	 return "UserLoginSuccess";
	}
	 else
	 {
	 return "UserLoginFailed";
	}
	}
	
	
	
	
	
	/*
	 * @GetMapping("login/{user_ID}/{user_FullName}/{user_password}") public String
	 * getLogin(@PathVariable int user_ID,@PathVariable String
	 * user_FullName, @PathVariable String user_password, Model model) { User user =
	 * null;
	 * 
	 * user = dao.getUserInfo(user_ID);
	 * 
	 * if (user_FullName.equals(user.getUser_FullName()) &&
	 * user_password.equals(user.getUser_password())) { return "success"; } else {
	 * 
	 * model.addAttribute("message", "Login Failed Please Enter Valid User Info");
	 * return "fail"; } }
	 * 
	 * @GetMapping("/displayLogin") public String getLoginInfo() { return
	 * "userLogin"; }
	 */
	@PutMapping(value="user/{user_password}/{user_FullName}/{newPassword}")
	public void updatePassword(@PathVariable String user_FullName, @PathVariable String newPassword)
	{
		dao.updatePassword(user_FullName, newPassword);
	}
	
	
	
	
	@PutMapping(value="userpass/{user_SecurityAnswer}/{nPassword}")
	public void forgotPassword(@PathVariable String user_SecurityAnswer, @PathVariable String nPassword)
	{
		dao.forgotPassword(user_SecurityAnswer, nPassword);
	}
	
	
	@DeleteMapping(value="user/{user_FullName}")
	public void deleteUser(@PathVariable String user_FullName)
	{
		dao.delete(user_FullName); 
		
	}
	
	
	@GetMapping(value="vechilegetall")
	public List<ShowVechiles> getall()
	{
	 return dao.Getall();
	}
	
	
	@GetMapping(value="usergetall")
	public List<ShowUser> getallusers()
	{
	 return dao.GetallUsers();
	}
	
	
	@GetMapping(value="vechilegetallvech/{vechtype}")
	public Object getallvech(@PathVariable String vechtype)
	{
	 return  dao.Getallvechiles(vechtype);
	}
	
	

	@GetMapping(value="vechilegetbymodel/{vechbrand}")
	public Object getbymodel(@PathVariable String vechbrand)
	{
	 return  dao.Getbymodel(vechbrand);
	}
	
	
	
	
	
	
	
		
	}
	
	



