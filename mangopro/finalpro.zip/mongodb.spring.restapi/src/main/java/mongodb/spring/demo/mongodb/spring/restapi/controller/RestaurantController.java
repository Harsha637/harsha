package mongodb.spring.demo.mongodb.spring.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import mongodb.spring.demo.mongodb.spring.restapi.dao.RestaurantDao;
import mongodb.spring.demo.mongodb.spring.restapi.model.Restaurant;

@CrossOrigin
@RestController
public class RestaurantController {

	
	
	
	@Autowired
	RestaurantDao dao;

	@PostMapping("saverest")
	public Restaurant saveRestuarant(@RequestBody Restaurant restuarant)
	{

	return dao.saveRestaurant(restuarant);

	}

	}

