package mongodb.spring.demo.mongodb.spring.restapi.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import mongodb.spring.demo.mongodb.spring.restapi.model.ShowVechiles;
import mongodb.spring.demo.mongodb.spring.restapi.model.User;
import mongodb.spring.demo.mongodb.spring.restapi.model.Vechile;
import mongodb.spring.demo.mongodb.spring.restapi.model.show.ShowUser;

@Component
public class UserDao {

	@Autowired
	MongoTemplate mongoTemplate;
	
	
	
	public User CreateUser(User user){
		try{
			
				mongoTemplate.save(user);
				return user;

				}
				catch (Exception e) {
				e.printStackTrace();

				}
				return null;

				}
	
	public ShowVechiles Createvech(ShowVechiles showvechiles){
		try{
			
				mongoTemplate.save(showvechiles);
				return showvechiles;

				}
				catch (Exception e) {
				e.printStackTrace();

				}
				return null;

				}
	
	

	

	
	
	
	

	
	
	

	public User getDetailsByName(String user_Name) {
		Query query = new Query();
		query.addCriteria(Criteria.where("user_Name").is(user_Name));
		User user= mongoTemplate.findOne(query,User.class);

		return user;

		   }
	
	public void updatePassword(String user_FullName, String nPassword)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("user_FullName").is(user_FullName));
		Update update=new Update();
		update.set("user_password", nPassword);
		mongoTemplate.updateFirst(query, update,User.class);
		
	}
	
	
	
	
	public void forgotPassword(String user_SecurityAnswer, String newPassword)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("user_SecurityAnswer").is(user_SecurityAnswer));
		Update update=new Update();
		update.set("user_password", newPassword);
		mongoTemplate.updateFirst(query, update,User.class);
		
	}
	
	
	
	
	
	
	public void delete(String user_FullName) {
		Query query = new Query();
		query.addCriteria(Criteria.where("user_FullName").is(user_FullName));
		mongoTemplate.findAndRemove(query, User.class);
	}
	

	public List<ShowVechiles> Getall() {
		return mongoTemplate.findAll(ShowVechiles.class);
	}
	
	
	public List<ShowUser> GetallUsers() {
		return mongoTemplate.findAll(ShowUser.class);
	}
	
	
	
	
	public Object Getallvechiles(String vechtype) {
	Query query = new Query();
	query.addCriteria(Criteria.where("vechtype").is(vechtype));
	Object showall = mongoTemplate.find(query,ShowVechiles.class);
	System.out.println(showall);
	return  showall;

	}
	
	
	
	public Object Getbymodel(String vechbrand) {
		Query query = new Query();
		query.addCriteria(Criteria.where("vechbrand").is(vechbrand));
		Object showbymodel = mongoTemplate.find(query,ShowVechiles.class);
		System.out.println(showbymodel);
		return  showbymodel;

		}
	

//	public User getUserInfo(int user_Id) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("user_ID").is(user_Id));
//		User usering= mongoTemplate.findOne(query,User.class);
//
//		return usering;
//	}
//	 
//	public User getSecInfo(int user_ID) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("user_ID").is(user_ID));
//		User usering= mongoTemplate.findOne(query,User.class);
//
//		return usering;
//		
//		
//		
//	}

	/*
	 * public void changePassword(String user_password,int userId) { User user =
	 * null; user = getSecInfo(userId); user.setUser_password(user_password); Query
	 * query = new Query(); query.addCriteria(Criteria.where("user_ID").is(userId));
	 * User using= mongoTemplate.findOne(query,User.class); Update update=new
	 * Update(); update.set("user_password",user_password);
	 * mongoTemplate.updateFirst(query, update, User.class);
	 * 
	 * }
	 * 
	 * 
	 */
	
	
	
	


}
