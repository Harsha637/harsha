package com.finalproject.finalproject;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.finalproject.finalproject.User.Bike;
import com.finalproject.finalproject.User.Car;
import com.finalproject.finalproject.User.NewUser;


import com.finalproject.finalproject.Admin.Admin;
import com.finalproject.finalproject.AdminDao.AdminDao;
import com.finalproject.finalproject.UserDao.UserDao;
import com.finalproject.finalproject.Vechile.Vechile;

import oracle.net.jdbc.TNSAddress.Address;


@Controller
public class HomeController {
	@Autowired
	UserDao dao;
	
	
	
	@RequestMapping(value="/user")
	public String homing()
	{
	return "home";
	}
	
	
	
	@RequestMapping(value="/Showroom")
	public String home(Model model)
	{
	return "Showroom";
	}
	@RequestMapping(value="/SignUp")
	public String SignUp(Model model)
	{
	return "SignUp";
	}
	
	@GetMapping("data")
	public String display(Model model,@ModelAttribute NewUser newuser)
	{
	String status=dao.CreateUser(newuser);
	model.addAttribute("status",status);
	return "display";
	}
	
	@GetMapping("logging")
	public String getLogg() {
		return "login";
	}
	
	@GetMapping("loginn")
	public String getLogin(@RequestParam("user_ID") int user_ID, @RequestParam("user_FullName") String user_FullName,
			@RequestParam("user_password") String user_password, Model model) {
		//System.out.println("Username : "+username);
		NewUser user = null;

		user = dao.getUserInfo(user_ID);
		
		if (user_FullName.equals(user.getUser_FullName()) && user_password.equals(user.getUser_password())) {
			return "success";
		}

		model.addAttribute("message", "Login Failed Please Enter Valid User Info");
		return "fail";
	}
	
	@GetMapping("/displayLogin")
	public String getLoginInfo() {
		return "userLogin";
	}
	
	
	@GetMapping("/main")
	public String getmain() {
		return "home";
	}
	
	
	@GetMapping("/forgot")
	public String getforgot() {
		return "forgotpassword";
	}
	
	
	
	@GetMapping("/pass")
	public String getSec(@RequestParam("user_ID") int user_ID,@RequestParam("user_SecurityQuestion") String user_SecurityQuestion,
			@RequestParam("user_SecurityAnswer") String user_SecurityAnswer,Model model) {
		NewUser user = null;

		user = dao.getUserInfo(user_ID);
		
		if (user_SecurityQuestion.equals(user.getUser_SecurityQuestion()) && user_SecurityAnswer.equals(user.getUser_SecurityAnswer())) {
			model.addAttribute("user_ID", user_ID);
			return "Changepass";
		}

		model.addAttribute("message", "Login Failed Please Enter Valid User Info");
		
				return "forgotpassword";
		
	}
	
	
	
	
     

	@GetMapping("/changepass")
	public String changpass(@RequestParam ("user_password")String user_password, @RequestParam ("conformPass")String conformPass,@RequestParam("user_ID") int user_ID) {
		//System.out.println("user_ID : "+user_ID);
		if(user_password.equals(conformPass)) {
			dao.changePassword(user_password,user_ID);
			return "changed";
		}
		else {
		return "ChangePass";
		}
}
	@RequestMapping("/bikes")
	public String showbike(Model model,Bike bike)
	{
		List<Bike> all = dao.getAll();
		
		model.addAttribute("all", all);
		return "allbikes";

	}
  
	
	@RequestMapping("/yourcart")
	public String cart()
	{
		
		return "get";

	}

	 
	@RequestMapping("/cars")
	public String shocar(Model model,Car car)
	{
		List<Car> all = dao.getAllcars();
		
		model.addAttribute("all", all);
		return "allcars";

	}
	@RequestMapping("/yourcart1")
	public String cart1()
	{
		
		return "get1";

	}
	@RequestMapping(value="/da")
	public String buy()
	{
	return "buy";
	}
	
	@GetMapping("data1")
	public String display(Model model,@ModelAttribute Address address)
	{
	String status1=dao.CreateAddr(address);
	model.addAttribute("status1",status1);
	return "display1";
	}
	@RequestMapping(value="/disp")
	public String disp()
	{
	return "display1";
	}
	
	@RequestMapping("/addrs")
	public String shoaddr(Model model,Address address)
	{
		List<Address> all = dao.getAddr();
		
		model.addAttribute("all", all);
		return "addr";

	}
	@RequestMapping(value="/card")
	public String card()
	{
	return "card";
	}
	@RequestMapping(value="/disp1")
	public String disp3()
	{
	return "display3";
	}
	
	
	

	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
