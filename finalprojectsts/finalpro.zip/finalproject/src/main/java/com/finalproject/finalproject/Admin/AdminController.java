package com.finalproject.finalproject.Admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.finalproject.finalproject.AdminDao.AdminDao;
import com.finalproject.finalproject.User.NewUser;
import com.finalproject.finalproject.Vechile.Vechile;
import com.finalproject.finalproject.Admin.Admin;

@Controller
public class AdminController {
	@Autowired
	AdminDao Dao;


	@RequestMapping(value="/admin")
	public String Admin()
	{
	return "Adminlogverify";
	}
	
	
	@RequestMapping("inserting")
	public String getinserting(){
	return "insert";
	
}


	@RequestMapping("updating")
	public String getupdate(){
	return "update";
	
}

	
	
	
	
	@GetMapping("logreg")
	public String display(Model model,@ModelAttribute Admin admin)
	{
	String status=Dao.CreateUser(admin);
	model.addAttribute("status",status);
	return "displayoptions";
	}
	
	
	@GetMapping("addloginng")
	public String getLoginAdd(@RequestParam("adminid") int adminid, @RequestParam("adminname") String adminname,
			@RequestParam("pass") String pass, Model model) {
		//System.out.println("Username : "+username);
		Admin add = null;

		add = Dao.getAdminInfo(adminid);
		
		if (adminname.equals(add.getAdminname()) && pass.equals(add.getPass())) {
			return "successAdmin";
		}

		model.addAttribute("message", "Login Failed Please Enter Valid User Info");
		return "failadmin";
	}
	
	@GetMapping("/displayLoginAdmin")
	public String getLoginInfoAdd() {
		return "AdminLogin";
	}
	
	
	@GetMapping("Adminlogg")
	public String LoggAdmin() {
		return "Adminlogg";
	}

	@GetMapping("forgotten")
	public String Loggforgotadmin() {
		return "Adminforgot";
	}
	
	@GetMapping("deleting")
	public String deleting() {
		return "delete";
	}
	
	
	
	
	
	
	
	
	@GetMapping("/passadd")
	public String getSecAdmin(@RequestParam("adminid") int adminid,@RequestParam("security_questions") String security_questions,
			@RequestParam("security_answers") String security_answers,Model model) {
		System.out.println(adminid);
		Admin admin = null;

		admin = Dao.getAdminInfo(adminid);
		
		if (security_questions.equals(admin.getSecurity_questions()) && security_answers.equals(admin.getSecurity_answers())) {
			model.addAttribute("adminid", adminid);
			return "Changepassadd";
		}

		model.addAttribute("message", "Login Failed Please Enter Valid User Info");
		
				return "forgotpasswordadd";
		
	}
	
	@GetMapping("/changepassad")
	public String changpass(@RequestParam ("pass")String pass, @RequestParam ("cPass")String cPass,@RequestParam("adminid") int adminid) {
		System.out.println(adminid);
		System.out.println(pass);
		System.out.println(cPass);
		if(pass.equals(cPass)) {
			Dao.changePassword(pass,adminid);
			return "changedadd";
		}
		else {
		return "ChangePassadd";
		}
}


	@GetMapping("/mainadd")
	public String getmainadd() {
		return "Adminlogverify";
	}
	
	
	
	
	
	@GetMapping("dataveh")
	public String getinsert(Model model,@ModelAttribute Vechile vechile) {
		String status=Dao.insert(vechile);
		model.addAttribute("status",status);
		return "displayinsert";
		
	
	}
	
	int vid=0;
	  
	  @RequestMapping(value="/searchForUpdate")
	  public String searchForUpdate(Model model,@RequestParam("vid")int vid) {
	 int stdid=vid;
	 this.vid=stdid;
	 Vechile update=Dao.updatingbyId(vid);
	 model.addAttribute(update);
	  //model.addAttribute("school",school);
	  return "update"; 
	  }
	  
	 
	 
	 @RequestMapping(value="/updatedata") 
	 public String updateData(Model model,@ModelAttribute Vechile vechile) {
	  vechile.setVid(vid);
	 // System.out.println(id);
	 String up=Dao.updateAll(vechile);
	 model.addAttribute("up",up);
	 //System.out.println(up);
	
	return "updating";
	}
	 
	
	 
	
	 @RequestMapping(value = "/del")
		public String delete1(Model model, @RequestParam("vid") int vid) {
			String status = Dao.delete(vid);
			// System.out.println(id);
			model.addAttribute("status", status);

			return "displayinsert";
		}
	
	 
	 @RequestMapping(value="/view")
		public String search(Model model, @ModelAttribute Vechile vechile) {
			List<Vechile> all = Dao.getAll();
			// System.out.println(status);
			model.addAttribute("all", all);
			return "viewall";
		}
	
	
	
	
}
