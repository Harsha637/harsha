package com.finalproject.finalproject.UserDao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.finalproject.finalproject.Admin.Admin;
import com.finalproject.finalproject.User.Bike;
import com.finalproject.finalproject.User.Car;
import com.finalproject.finalproject.User.NewUser;

import oracle.net.jdbc.TNSAddress.Address;

@Component
@Transactional
public class UserDao {
	@Autowired
	SessionFactory factory;
	public UserDao() {
		// TODO Auto-generated constructor stub
	}
	public UserDao(SessionFactory factory) {
		super();
		this.factory = factory;
		}
	public String  CreateUser(NewUser newUser){
		try{
		Session session=factory.getCurrentSession();
		session.save(newUser);
		return "Successfully Created Account In Our Portal";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return "Cannot Create Account In Our Portal Beacause Data Already Used";
		}
	
	
	
	
	public NewUser getUserInfo(int user_Id) {
		Session session = null;
		NewUser user = null;

		session = factory.getCurrentSession();
		user = session.get(NewUser.class, user_Id);
		System.out.println("User Data : "+user);
		
		return user;
	}
	 
	public NewUser getSecInfo(int user_ID) {
		Session session = null;
		NewUser user = null;
		session = factory.getCurrentSession();
		user = session.get(NewUser.class, user_ID);
		return user;
		
	}

	public void changePassword(String password,int userId) {
		NewUser user = null;
		Session session = null;
		
		user = getSecInfo(userId);
		user.setUser_password(password);

		session = this.factory.getCurrentSession();
		
			session.update(user);
	}
	public List<Bike> getAll(){

		try{
		Session session=factory.getCurrentSession();
		Criteria crit = session.createCriteria(Bike.class);
		Query query=session.createQuery("from Bike ");
		List byAll = query.list();
		
		return byAll;

		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return null;
		}
	
	public List<Car> getAllcars(){

		try{
		Session session=factory.getCurrentSession();
		Criteria crit = session.createCriteria(Car.class);
		Query query=session.createQuery("from Car ");
		List byAll = query.list();
		
		return byAll;

		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return null;
		}
	public String  CreateAddr(Address address){
		try{
		Session session=factory.getCurrentSession();
		session.save(address);
		return "inserted";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return "not";
		}
	public List<Address> getAddr(){

		try{
		Session session=factory.getCurrentSession();
		Criteria crit = session.createCriteria(Address.class);
		Query query=session.createQuery("from Address ");
		List byAll = query.list();
		
		return byAll;

		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return null;
		}
	
	
}
