package com.finalproject.finalproject.User;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class address {
    @Id
	private int anumber;
	private String aname;
	private String amail;
	private String addr;
	public int getAnumber() {
		return anumber;
	}
	public void setAnumber(int anumber) {
		this.anumber = anumber;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getAmail() {
		return amail;
	}
	public void setAmail(String amail) {
		this.amail = amail;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "address [anumber=" + anumber + ", aname=" + aname + ", amail=" + amail + ", addr=" + addr + "]";
	}
	public address(int anumber, String aname, String amail, String addr) {
		super();
		this.anumber = anumber;
		this.aname = aname;
		this.amail = amail;
		this.addr = addr;
	}
	
	public address() {
		
	}
	
}
