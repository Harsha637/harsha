package com.finalproject.finalproject.User;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bike {
	@Id
int	bid ;
	  public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBprice() {
		return bprice;
	}
	public void setBprice(String bprice) {
		this.bprice = bprice;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	String bname;
	  String bprice;
	  String  status;
	@Override
	public String toString() {
		return "Bike [bid=" + bid + ", bname=" + bname + ", bprice=" + bprice + ", status=" + status + "]";
	}
	public Bike(int bid, String bname, String bprice, String status) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.bprice = bprice;
		this.status = status;
	}
	   
	public Bike() {
		// TODO Auto-generated constructor stub
	}
	

}
