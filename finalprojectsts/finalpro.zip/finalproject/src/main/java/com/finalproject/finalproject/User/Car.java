package com.finalproject.finalproject.User;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Car {
	@Id
	private int cid;
	private String cname;
	private String cprice;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCprice() {
		return cprice;
	}
	public void setCprice(String cprice) {
		this.cprice = cprice;
	}
	@Override
	public String toString() {
		return "Car [cid=" + cid + ", cname=" + cname + ", cprice=" + cprice + "]";
	}
	public Car(int cid, String cname, String cprice) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cprice = cprice;
	}
	public Car() {
		// TODO Auto-generated constructor stub
	}

}
